﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ManageGame
{
    public partial class Subform1 : Form
    {
        static readonly string Password = Properties.Settings.Default.Password;
        public Subform1()
        {
            InitializeComponent();
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
        }

        private void Subform1_Load(object sender, EventArgs e)
        {
            this.Text = "Instructions";
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }
    }
}
