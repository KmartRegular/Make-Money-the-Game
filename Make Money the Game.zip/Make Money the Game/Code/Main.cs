﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ManageGame
{
    public partial class Main : Form
    {
        Random rng = new Random();
        static int PlayerMoney = Properties.Settings.Default.PlayerCash;
        static int PlayerMoneyIncrement = Properties.Settings.Default.PlayerCashIncrement;
        static int PrinterCost = Properties.Settings.Default.PrinterCost;
        static int PrintersOwned = Properties.Settings.Default.PrintersOwned;
        static int PrintedPerSec = Properties.Settings.Default.PrintedPerSec;
        static int _PrintedPerSec = Properties.Settings.Default._PrintedPerSec; 
        static int Employees = Properties.Settings.Default.Employees; //owned employees
        static int EmployeeIncome = Properties.Settings.Default.EmployeeIncome; //Income per minute
        static int IncomePerEmployee = Properties.Settings.Default.IncomePerEmployee; //income per emplyoee
        static int EmployeePrice = Properties.Settings.Default.EmployeePrice; //price per employee
        static bool Upgrade = Properties.Settings.Default.Upgrade; //Larger printers
        static bool Upgrade1 = Properties.Settings.Default.Upgrade1; //Moneymaker's mouse
        static bool Upgrade2 = Properties.Settings.Default.Upgrade2; //Printer overdrive
        static bool Upgrade3 = Properties.Settings.Default.Upgrade3; //Money rain
        static bool Upgrade4 = Properties.Settings.Default.Upgrade4; //Outsourced Labor
        static bool Upgrade5 = Properties.Settings.Default.Upgrade5; //not in use
        static bool Upgrade6 = Properties.Settings.Default.Upgrade6; //not in use
        static bool Upgrade7 = Properties.Settings.Default.Upgrade7; //not in use
        static bool Upgrade8 = Properties.Settings.Default.Upgrade8; //not in use
        static bool Upgrade9 = Properties.Settings.Default.Upgrade9; //not in use
        static int Soldiers = Properties.Settings.Default.Soldiers;
        static int Barracks = Properties.Settings.Default.Barracks;
        static int OpsCenters = Properties.Settings.Default.OpsCenters;
        static int EquipmentLvl = Properties.Settings.Default.EquipmentLvl;
        static int OverthrownNations = Properties.Settings.Default.OverthrownNations;
        static int OverthrowChance = Properties.Settings.Default.OverthrowChance;
        static int MaxSoldiers = Properties.Settings.Default.MaxSoldiers;
        static int MaxResearchers = Properties.Settings.Default.MaxResearchers;
        static int Researchers = Properties.Settings.Default.Researchers;
        static int OverthrowModifier = Properties.Settings.Default.OverthrowModifier;
        public Main()
        {
            InitializeComponent();
        }
        private void Form1_Load(object sender, EventArgs e) //game window
        {
            this.Text = "Make Money the Game";
            //PlayerMoney = 0;
        }
        private void timer1_Tick(object sender, EventArgs e) //updates labels and some other stuff (put label text containing stats here so it refreshes)
        {
            Moneylabel.Text = $"Cash: ${PlayerMoney}";
            IncrementLabel.Text = $"Money per click: {PlayerMoneyIncrement}";
            mpcButton.Text = $"Buy Money Printer (${PrinterCost})";
            Mplabel.Text = $"Printers: {PrintersOwned}";
            EmployeesLabel.Text = $"Employees: {Employees}";
            HireButton.Text = $"Hire Employee (${EmployeePrice})";
            EmployeeIncomeLabel.Text = $"Income per min: ${EmployeeIncome}";
            SoilderLabel.Text = $"Soilders: {Soldiers}/{MaxSoldiers}";
            BarracksLabel.Text = $"Barracks: {Barracks}";
            OpsCenterLabel.Text = $"Ops Centers: {OpsCenters}";
            OverthrownLabel.Text = $"Nations Overthrown: {OverthrownNations}/195";
            OverthrowChanceLabel.Text = $"Successful Overthrow: {OverthrowChance}%";
            ResearcherLabel.Text = $"Researchers: {Researchers}";

            if ( Upgrade2 == true)
            {
                Mpplabel.Text = $"Money per half sec from printers: ${PrintedPerSec}";
            }
            else
            {
                Mpplabel.Text = $"Money per sec from printers: ${PrintedPerSec}";
            }            

            if (Soldiers == MaxSoldiers) //limits soldiers
            {
                MilitiaButton.Enabled = false;
            }
            else if (Soldiers < MaxSoldiers)
            {
                MilitiaButton.Enabled = true;
            }
        }
        private void PrinterUpdate_Tick(object sender, EventArgs e) //Adds money every second
        {
            PlayerMoney += PrintedPerSec;
            Moneylabel.Text = $"Cash: ${PlayerMoney}";
        }
        private void label1_Click(object sender, EventArgs e) //money label
        {

        }

        private void button1_Click(object sender, EventArgs e) //money making button
        {
            PlayerMoney += PlayerMoneyIncrement;
            Moneylabel.Text = $"Cash: ${PlayerMoney}";
        }

        private void IncrementLabel_Click(object sender, EventArgs e) //money per click label
        {

        }
        private async void mpcButton_Click(object sender, EventArgs e) //buys printer
        {
            mpcButton.Text = $"Buy Money Printer (${PrinterCost})";
            if (PlayerMoney >= PrinterCost)
            {
                PrintersOwned += 1;
                PlayerMoney -= PrinterCost;
                PrintedPerSec += _PrintedPerSec;
                PrinterCost += 5;
            }
            else
            {
                CALabel.Visible = true;
                await Task.Delay(2000);
                CALabel.Visible = false;
            }
        }
        private void Mplabel_Click(object sender, EventArgs e) //Shows amount of printers
        {

        }
        private void Mpplabel_Click(object sender, EventArgs e) //Shows the money per sec
        {

        }

        private void label1_Click_1(object sender, EventArgs e) //Cant afford label
        {

        }

        private void AutoSave_Tick(object sender, EventArgs e) //Auto saves every 10 seconds
        {
            Properties.Settings.Default.Save();
        }

        private void UpgradePanel_Paint(object sender, PaintEventArgs e)
        {
            AddButtonToPanel("Larger Printers ($100)");
            if (Upgrade == true)
            {
                AddButtonToPanel("Moneymaker's Mouse ($150)");
            }
            if (Upgrade1 == true)
            {
                AddButtonToPanel("Printer Overdrive ($500)");
            }
            if (Upgrade2 == true)
            {
                AddButtonToPanel("Cloud Seeding ($1000)");
            }
            if (Upgrade3 == true)
            {
                AddButtonToPanel("Outsourced Labor Permit ($5000)");
            }
            if (Upgrade4 == true)
            {
                AddButtonToPanel("Employee Training Program ($10000)");
            }
            if (Upgrade5 == true)
            {
                AddButtonToPanel("Outsource labor to 3rd world countries ($50000)");
            }
            if (Upgrade6 == true)
            {
                AddButtonToPanel("Fund local insurgency groups ($100000)");
            }
        }
        private void AddButtonToPanel(string Buttontext) //Adds button to UpgradePanel
        {
            foreach (Control control in UpgradePanel.Controls)
            {
                if (control is Button && control.Text == Buttontext)
                {
                    return;
                }
            }
            Button button = new Button();
            button.Text = Buttontext;
            button.Size = new Size(150, 40);
            button.Location = new Point(10, UpgradePanel.Controls.Count * 40);
            button.Click += ButtonClick;
            UpgradePanel.Controls.Add(button);
        }
        private async void ButtonClick(object sender, EventArgs e) //Add if statements for each upgrade button
        {
            Button ClickedButton = (Button)sender;
            if (ClickedButton.Text == "Larger Printers ($100)")
            {
                if (PlayerMoney >= 100)
                {
                    Upgrade = true;
                    PrintedPerSec += 1 * PrintersOwned;
                    _PrintedPerSec += 1;
                    PlayerMoney -= 100;
                    UpgradeLabel.Text = "Printer power increased by $1";
                    ClickedButton.Enabled = false;
                    UpgradeLabel.Visible = true;
                    await Task.Delay(5000);
                    UpgradeLabel.Visible = false;
                }
                else
                {
                    CALabel.Visible = true;
                    await Task.Delay(2000);
                    CALabel.Visible = false;
                }
            }
            if (ClickedButton.Text == "Moneymaker's Mouse ($150)")
            {
                if (PlayerMoney >= 150)
                {
                    Upgrade1 = true;
                    PlayerMoneyIncrement++;
                    PlayerMoney -= 150;
                    ClickedButton.Enabled = false;
                    UpgradeLabel.Text = $"Each click now gives $2";
                    UpgradeLabel.Visible = true;
                    await Task.Delay(5000);
                    UpgradeLabel.Visible= false;
                }
                else
                {
                    CALabel.Visible = true;
                    await Task.Delay(2000);
                    CALabel.Visible = false;
                }
            }
            if (ClickedButton.Text == "Printer Overdrive ($500)")
            {
                if (PlayerMoney >= 500)
                {
                    Upgrade2 = true;
                    PrinterUpdate.Interval = (500);
                    PlayerMoney -= 500;
                    ClickedButton.Enabled = false;
                    UpgradeLabel.Text = ("Printers are twice as fast now");
                    UpgradeLabel.Visible = true;
                    await Task.Delay(5000);
                    UpgradeLabel.Visible = false;
                }
                else
                {
                    CALabel.Visible= true;
                    await Task.Delay(2000);
                    CALabel.Visible = false;
                }
            }
            if (ClickedButton.Text == "Cloud Seeding ($1000)")
            {
                if (PlayerMoney >= 1000)
                {
                    Upgrade3 = true;
                    PlayerMoney -= 1000;
                    ClickedButton.Enabled = false;
                    UpgradeLabel.Text = "Money rains from the sky???";
                    UpgradeLabel.Visible = true;
                    await Task.Delay(5000);
                    UpgradeLabel.Visible = false;
                }
                else
                {
                    CALabel.Visible = true;
                    await Task.Delay(2000);
                    CALabel.Visible = false;
                }
            }
            if (ClickedButton.Text == "Outsourced Labor Permit ($5000)")
            {
                if (PlayerMoney >= 5000)
                {
                    ClickedButton.Enabled = false;
                    Upgrade4 = true;
                    PlayerMoney -= 5000;
                    HireButton.Enabled = true;
                    HireButton.Visible = true;
                    EmployeesLabel.Visible = true;
                    EmployeeIncomeLabel.Visible = true;

                    UpgradeLabel.Text = "You can now 'hire' employees";
                    UpgradeLabel.Visible = true;
                    await Task.Delay(5000);
                    UpgradeLabel.Visible = false;
                }
                else
                {
                    CALabel.Visible = true;
                    await Task.Delay(2000);
                    CALabel.Visible = false;
                }
            }
            if (ClickedButton.Text == "Employee Training Program ($10000)")
            {
                if (PlayerMoney >= 10000)
                {
                    Upgrade5 = true;
                    ClickedButton.Enabled = false;
                    PlayerMoney -= 10000;
                    IncomePerEmployee = 750;

                    UpgradeLabel.Text = "Employees now make $250 more per minute";
                    UpgradeLabel.Visible = true;
                    await Task.Delay(5000);
                    CALabel.Visible = false;
                }
                else
                {
                    CALabel.Visible = true;
                    await Task.Delay(2000);
                    CALabel.Visible = false;
                }
            }
            if (ClickedButton.Text == "Outsource labor to 3rd world countries ($50000)")
            {
                if (PlayerMoney >= 50000)
                {
                    Upgrade6 = true;
                    ClickedButton.Enabled = false;
                    PlayerMoney -= 50000;
                    EmployeePrice = 100;

                    UpgradeLabel.Text = "Due to poor labor laws here employees are cheaper hires";
                    UpgradeLabel.Visible = true;
                    await Task.Delay(5000);
                    UpgradeLabel.Visible = false;
                }
                else
                {
                    CALabel.Visible = true;
                    await Task.Delay(2000);
                    CALabel.Visible = false;
                }
            }
            if (ClickedButton.Text == "Fund local insurgency groups ($100000)")
            {
                if (PlayerMoney >= 100000)
                {
                    MilitiaButton.Enabled = true;
                    MilitiaButton.Visible = true;
                    TakeoverButton.Enabled = true;
                    TakeoverButton.Visible = true;
                    ResearcherButton.Enabled = true;
                    ResearcherButton.Visible = true;
                    ResearcherLabel.Visible = true;
                    BarracksButton.Enabled = true;
                    BarracksButton.Visible = true;
                    SoilderLabel.Visible = true;
                    BarracksLabel.Visible = true;
                    OpsCenterLabel.Visible = true;
                    EquipmentLabel.Visible = true;
                    OverthrownLabel.Visible = true;
                    OverthrowChanceLabel.Visible = true;
                    EquipmentInfoLabel.Visible = true;

                    Upgrade7 = true;
                    PlayerMoney -= 100000;
                    ClickedButton.Enabled = false;
                }
                else
                {
                    CALabel.Visible = true;
                    await Task.Delay(2000);
                    CALabel.Visible = false;
                }
            }
        }
        private void UpgradeLabel_Click(object sender, EventArgs e) //Label that displays when upgrade is bought
        {

        }

        private void MoneyRain_Tick(object sender, EventArgs e) //The money rain upgrade
        {
            if ( Upgrade3 == true)
            {
                PlayerMoney++;
            }
            else
            {
                return;
            }
        }

        private void InstructionButton_Click(object sender, EventArgs e) //opens instuctions window
        {
            Subform1 subform1 = new Subform1();
            subform1.Show();
        }

        private void EmployeesLabel_Click(object sender, EventArgs e)
        {

        }
        private void EmployeeIncomeLabel_Click(object sender, EventArgs e)
        {

        }
        private async void HireButton_Click(object sender, EventArgs e) //Button that hires employees
        {
            if (PlayerMoney >= EmployeePrice)
            {
                PlayerMoney -= EmployeePrice;
                Employees++;
                EmployeeIncome = IncomePerEmployee * Employees;
                EmployeePrice += 100;
            }
            else
            {
                CALabel.Visible = true;
                await Task.Delay(2000);
                CALabel.Visible = false;
            }
        }
        private void EmployeeIncomeTimer_Tick(object sender, EventArgs e)
        {
            PlayerMoney += EmployeeIncome;
        }
        private void OpsCenterButton_Click(object sender, EventArgs e) //Buys ops centers
        {
            
        }
        private async void BarracksButton_Click(object sender, EventArgs e) //Buys barracks
        {
            if (PlayerMoney >= 100000 && Barracks < 3)
            {
                PlayerMoney -= 100000;
                Barracks++;
                MaxSoldiers += 100;
            }
            else if (PlayerMoney < 100000)
            {
                CALabel.Visible = true;
                await Task.Delay(2000);
                CALabel.Visible = false;
            }
            if (Barracks == 4)
            {
                BarracksButton.Enabled = false;
                BarracksButton.Text = "Max Bought";
            }
        }
        private async void MilitiaButton_Click(object sender, EventArgs e) //Buys militia soldiers
        {
            if (PlayerMoney >= 1000 && Soldiers < MaxSoldiers)
            {
                Soldiers++;
                PlayerMoney -= 1000;                
            }
            else if (PlayerMoney < 1000)
            {
                CALabel.Visible = true;
                await Task.Delay(2000);
                CALabel.Visible = false;
            }

            switch (Soldiers)
            {
                case 100:
                    OverthrowChance += 10;
                    break;
                case 200:
                    OverthrowChance += 10;
                    break;
                case 300:
                    OverthrowChance += 10;
                    break;
                case 400:
                    OverthrowChance += 10;
                    break;
            }
        }
        private async void TakeoverButton_Click(object sender, EventArgs e) //Attempts takeover
        {
            if (PlayerMoney >= 100000)
            {
                OverthrowModifier = rng.Next(1, 101);
                OverthrowModifier += OverthrowChance;
                if (OverthrowModifier > 100)
                {
                    OverthrownNations++;
                }
                else
                {
                    CALabel.Text = "Failed";
                    CALabel.Visible = true;
                    await Task.Delay(2000);
                    CALabel.Text = "Lost 100 Soldiers";
                    Soldiers -= 100;
                    await Task.Delay(2000);
                    CALabel.Visible = false;
                    CALabel.Text = "Can't Afford";
                }
            }
            else
            {
                CALabel.Visible = true;
                await Task.Delay(2000);
                CALabel.Visible = false;
            }
            if (OverthrownNations == 195)
            {
                Win win = new Win();
                win.Show();
            }
        }
        private async void ResearcherButton_Click(object sender, EventArgs e) //Buys researcher
        {
            if (PlayerMoney >= 25000)
            {
                Researchers++;
                PlayerMoney -= 25000;
            }
            else
            {
                CALabel.Visible = true;
                await Task.Delay(2000);
                CALabel.Visible = false;
            }
            switch (Researchers)
            {
                case 25:
                    EquipmentLvl++;
                    EquipmentLabel.Text = "Equipment Level: U.S Military Surplus";
                    OverthrowChance += 15;
                    break;
                case 50:
                    EquipmentLvl++;
                    EquipmentLabel.Text = "Equipment Level: Modern U.S Surplus";
                    OverthrowChance += 15;
                    break;
                case 75: 
                    EquipmentLvl++;
                    EquipmentLabel.Text = "Equipment Level: Advanced Cybernetics";
                    OverthrowChance += 15;
                    break;
                case 100:
                    EquipmentLvl++;
                    EquipmentLabel.Text = "Equipment Level: Remade Alien Tech";
                    OverthrowChance += 15;
                    break;
            }
            if (Researchers == 100)
            {
                ResearcherButton.Enabled = false;
                ResearcherButton.Text = "Max Bought";
            }
        }
        private void SoilderLabel_Click(object sender, EventArgs e)
        {
           
        }
        private void BarracksLabel_Click(object sender, EventArgs e)
        {

        }
        private void OpsCenterLabels_Click(object sender, EventArgs e)
        {

        }
        private void EquipmentLabel_Click(object sender, EventArgs e)
        {

        }
        private void OverthrownLabel_Click(object sender, EventArgs e)
        {

        }
        private void OverthrowChanceLabel_Click(object sender, EventArgs e)
        {

        }
        private void EquipmentInfoLabel_Click(object sender, EventArgs e)
        {

        }
    }   
}
