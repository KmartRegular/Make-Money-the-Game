﻿namespace ManageGame
{
    partial class Main
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Main));
            this.Moneylabel = new System.Windows.Forms.Label();
            this.Moneybutton = new System.Windows.Forms.Button();
            this.IncrementLabel = new System.Windows.Forms.Label();
            this.mpcButton = new System.Windows.Forms.Button();
            this.Mplabel = new System.Windows.Forms.Label();
            this.Mpplabel = new System.Windows.Forms.Label();
            this.CALabel = new System.Windows.Forms.Label();
            this.UpdateLabels = new System.Windows.Forms.Timer(this.components);
            this.PrinterUpdate = new System.Windows.Forms.Timer(this.components);
            this.AutoSave = new System.Windows.Forms.Timer(this.components);
            this.UpgradePanel = new System.Windows.Forms.Panel();
            this.UpgradeLabel = new System.Windows.Forms.Label();
            this.MoneyRain = new System.Windows.Forms.Timer(this.components);
            this.InstructionButton = new System.Windows.Forms.Button();
            this.HireButton = new System.Windows.Forms.Button();
            this.EmployeesLabel = new System.Windows.Forms.Label();
            this.EmployeeIncomeLabel = new System.Windows.Forms.Label();
            this.EmployeeIncomeTimer = new System.Windows.Forms.Timer(this.components);
            this.MilitiaButton = new System.Windows.Forms.Button();
            this.SoilderLabel = new System.Windows.Forms.Label();
            this.OpsCenterLabel = new System.Windows.Forms.Label();
            this.OverthrownLabel = new System.Windows.Forms.Label();
            this.TakeoverButton = new System.Windows.Forms.Button();
            this.BarracksLabel = new System.Windows.Forms.Label();
            this.EquipmentLabel = new System.Windows.Forms.Label();
            this.OverthrowChanceLabel = new System.Windows.Forms.Label();
            this.ResearcherButton = new System.Windows.Forms.Button();
            this.BarracksButton = new System.Windows.Forms.Button();
            this.EquipmentInfoLabel = new System.Windows.Forms.Label();
            this.ResearcherLabel = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // Moneylabel
            // 
            this.Moneylabel.AutoSize = true;
            this.Moneylabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Moneylabel.Location = new System.Drawing.Point(13, 9);
            this.Moneylabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Moneylabel.Name = "Moneylabel";
            this.Moneylabel.Size = new System.Drawing.Size(127, 32);
            this.Moneylabel.TabIndex = 0;
            this.Moneylabel.Text = "Cash: $0";
            this.Moneylabel.Click += new System.EventHandler(this.label1_Click);
            // 
            // Moneybutton
            // 
            this.Moneybutton.BackColor = System.Drawing.SystemColors.Control;
            this.Moneybutton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Moneybutton.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Moneybutton.Location = new System.Drawing.Point(13, 96);
            this.Moneybutton.Margin = new System.Windows.Forms.Padding(4);
            this.Moneybutton.Name = "Moneybutton";
            this.Moneybutton.Size = new System.Drawing.Size(214, 59);
            this.Moneybutton.TabIndex = 1;
            this.Moneybutton.Text = "Make Money";
            this.Moneybutton.UseVisualStyleBackColor = false;
            this.Moneybutton.Click += new System.EventHandler(this.button1_Click);
            // 
            // IncrementLabel
            // 
            this.IncrementLabel.AutoSize = true;
            this.IncrementLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.IncrementLabel.Location = new System.Drawing.Point(13, 52);
            this.IncrementLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.IncrementLabel.Name = "IncrementLabel";
            this.IncrementLabel.Size = new System.Drawing.Size(257, 32);
            this.IncrementLabel.TabIndex = 2;
            this.IncrementLabel.Text = "Money per click: $1";
            this.IncrementLabel.Click += new System.EventHandler(this.IncrementLabel_Click);
            // 
            // mpcButton
            // 
            this.mpcButton.BackColor = System.Drawing.SystemColors.Control;
            this.mpcButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.mpcButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mpcButton.Location = new System.Drawing.Point(13, 161);
            this.mpcButton.Margin = new System.Windows.Forms.Padding(4);
            this.mpcButton.Name = "mpcButton";
            this.mpcButton.Size = new System.Drawing.Size(519, 59);
            this.mpcButton.TabIndex = 3;
            this.mpcButton.Text = "Buy Money Printer ($10)";
            this.mpcButton.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.mpcButton.UseVisualStyleBackColor = false;
            this.mpcButton.Click += new System.EventHandler(this.mpcButton_Click);
            // 
            // Mplabel
            // 
            this.Mplabel.AutoSize = true;
            this.Mplabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.857143F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Mplabel.Location = new System.Drawing.Point(537, 161);
            this.Mplabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Mplabel.Name = "Mplabel";
            this.Mplabel.Size = new System.Drawing.Size(121, 29);
            this.Mplabel.TabIndex = 4;
            this.Mplabel.Text = "Printers: 0";
            this.Mplabel.Click += new System.EventHandler(this.Mplabel_Click);
            // 
            // Mpplabel
            // 
            this.Mpplabel.AutoSize = true;
            this.Mpplabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.857143F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Mpplabel.Location = new System.Drawing.Point(537, 190);
            this.Mpplabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Mpplabel.Name = "Mpplabel";
            this.Mpplabel.Size = new System.Drawing.Size(350, 29);
            this.Mpplabel.TabIndex = 5;
            this.Mpplabel.Text = "Money per sec from printers: $0";
            this.Mpplabel.Click += new System.EventHandler(this.Mpplabel_Click);
            // 
            // CALabel
            // 
            this.CALabel.AutoSize = true;
            this.CALabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CALabel.ForeColor = System.Drawing.Color.Red;
            this.CALabel.Location = new System.Drawing.Point(986, 9);
            this.CALabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.CALabel.Name = "CALabel";
            this.CALabel.Size = new System.Drawing.Size(162, 32);
            this.CALabel.TabIndex = 6;
            this.CALabel.Text = "Can\'t Afford";
            this.CALabel.Visible = false;
            this.CALabel.Click += new System.EventHandler(this.label1_Click_1);
            // 
            // UpdateLabels
            // 
            this.UpdateLabels.Enabled = true;
            this.UpdateLabels.Interval = 10;
            this.UpdateLabels.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // PrinterUpdate
            // 
            this.PrinterUpdate.Enabled = true;
            this.PrinterUpdate.Interval = 1000;
            this.PrinterUpdate.Tick += new System.EventHandler(this.PrinterUpdate_Tick);
            // 
            // AutoSave
            // 
            this.AutoSave.Enabled = true;
            this.AutoSave.Interval = 10000;
            this.AutoSave.Tick += new System.EventHandler(this.AutoSave_Tick);
            // 
            // UpgradePanel
            // 
            this.UpgradePanel.AutoScroll = true;
            this.UpgradePanel.BackColor = System.Drawing.SystemColors.Control;
            this.UpgradePanel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.UpgradePanel.Location = new System.Drawing.Point(13, 242);
            this.UpgradePanel.Margin = new System.Windows.Forms.Padding(4);
            this.UpgradePanel.Name = "UpgradePanel";
            this.UpgradePanel.Size = new System.Drawing.Size(455, 471);
            this.UpgradePanel.TabIndex = 7;
            this.UpgradePanel.Paint += new System.Windows.Forms.PaintEventHandler(this.UpgradePanel_Paint);
            // 
            // UpgradeLabel
            // 
            this.UpgradeLabel.AutoSize = true;
            this.UpgradeLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.UpgradeLabel.ForeColor = System.Drawing.Color.Green;
            this.UpgradeLabel.Location = new System.Drawing.Point(13, 850);
            this.UpgradeLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.UpgradeLabel.Name = "UpgradeLabel";
            this.UpgradeLabel.Size = new System.Drawing.Size(166, 32);
            this.UpgradeLabel.TabIndex = 8;
            this.UpgradeLabel.Text = "Placeholder";
            this.UpgradeLabel.Visible = false;
            this.UpgradeLabel.Click += new System.EventHandler(this.UpgradeLabel_Click);
            // 
            // MoneyRain
            // 
            this.MoneyRain.Enabled = true;
            this.MoneyRain.Tick += new System.EventHandler(this.MoneyRain_Tick);
            // 
            // InstructionButton
            // 
            this.InstructionButton.Location = new System.Drawing.Point(1009, 833);
            this.InstructionButton.Name = "InstructionButton";
            this.InstructionButton.Size = new System.Drawing.Size(140, 46);
            this.InstructionButton.TabIndex = 9;
            this.InstructionButton.Text = "Instructions";
            this.InstructionButton.UseVisualStyleBackColor = true;
            this.InstructionButton.Click += new System.EventHandler(this.InstructionButton_Click);
            // 
            // HireButton
            // 
            this.HireButton.BackColor = System.Drawing.SystemColors.Control;
            this.HireButton.Enabled = false;
            this.HireButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.HireButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.857143F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.HireButton.Location = new System.Drawing.Point(476, 242);
            this.HireButton.Margin = new System.Windows.Forms.Padding(4);
            this.HireButton.Name = "HireButton";
            this.HireButton.Size = new System.Drawing.Size(214, 81);
            this.HireButton.TabIndex = 10;
            this.HireButton.Text = "Hire Employee ($250)";
            this.HireButton.UseVisualStyleBackColor = false;
            this.HireButton.Visible = false;
            this.HireButton.Click += new System.EventHandler(this.HireButton_Click);
            // 
            // EmployeesLabel
            // 
            this.EmployeesLabel.AutoSize = true;
            this.EmployeesLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.857143F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.EmployeesLabel.Location = new System.Drawing.Point(698, 253);
            this.EmployeesLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.EmployeesLabel.Name = "EmployeesLabel";
            this.EmployeesLabel.Size = new System.Drawing.Size(159, 29);
            this.EmployeesLabel.TabIndex = 11;
            this.EmployeesLabel.Text = "Employees: 0";
            this.EmployeesLabel.Visible = false;
            this.EmployeesLabel.Click += new System.EventHandler(this.EmployeesLabel_Click);
            // 
            // EmployeeIncomeLabel
            // 
            this.EmployeeIncomeLabel.AutoSize = true;
            this.EmployeeIncomeLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.857143F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.EmployeeIncomeLabel.Location = new System.Drawing.Point(698, 282);
            this.EmployeeIncomeLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.EmployeeIncomeLabel.Name = "EmployeeIncomeLabel";
            this.EmployeeIncomeLabel.Size = new System.Drawing.Size(217, 29);
            this.EmployeeIncomeLabel.TabIndex = 12;
            this.EmployeeIncomeLabel.Text = "Income per min: $0";
            this.EmployeeIncomeLabel.Visible = false;
            this.EmployeeIncomeLabel.Click += new System.EventHandler(this.EmployeeIncomeLabel_Click);
            // 
            // EmployeeIncomeTimer
            // 
            this.EmployeeIncomeTimer.Enabled = true;
            this.EmployeeIncomeTimer.Interval = 60000;
            this.EmployeeIncomeTimer.Tick += new System.EventHandler(this.EmployeeIncomeTimer_Tick);
            // 
            // MilitiaButton
            // 
            this.MilitiaButton.BackColor = System.Drawing.SystemColors.Control;
            this.MilitiaButton.Enabled = false;
            this.MilitiaButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.MilitiaButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.857143F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MilitiaButton.Location = new System.Drawing.Point(476, 330);
            this.MilitiaButton.Margin = new System.Windows.Forms.Padding(4);
            this.MilitiaButton.Name = "MilitiaButton";
            this.MilitiaButton.Size = new System.Drawing.Size(214, 81);
            this.MilitiaButton.TabIndex = 13;
            this.MilitiaButton.Text = "Recruit Soldier ($1000)";
            this.MilitiaButton.UseVisualStyleBackColor = false;
            this.MilitiaButton.Visible = false;
            this.MilitiaButton.Click += new System.EventHandler(this.MilitiaButton_Click);
            // 
            // SoilderLabel
            // 
            this.SoilderLabel.AutoSize = true;
            this.SoilderLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.857143F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SoilderLabel.Location = new System.Drawing.Point(698, 311);
            this.SoilderLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.SoilderLabel.Name = "SoilderLabel";
            this.SoilderLabel.Size = new System.Drawing.Size(174, 29);
            this.SoilderLabel.TabIndex = 14;
            this.SoilderLabel.Text = "Soilders: 0/100";
            this.SoilderLabel.Visible = false;
            this.SoilderLabel.Click += new System.EventHandler(this.SoilderLabel_Click);
            // 
            // OpsCenterLabel
            // 
            this.OpsCenterLabel.AutoSize = true;
            this.OpsCenterLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.857143F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.OpsCenterLabel.Location = new System.Drawing.Point(699, 369);
            this.OpsCenterLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.OpsCenterLabel.Name = "OpsCenterLabel";
            this.OpsCenterLabel.Size = new System.Drawing.Size(173, 29);
            this.OpsCenterLabel.TabIndex = 15;
            this.OpsCenterLabel.Text = "Ops Centers: 0";
            this.OpsCenterLabel.Visible = false;
            this.OpsCenterLabel.Click += new System.EventHandler(this.OpsCenterLabels_Click);
            // 
            // OverthrownLabel
            // 
            this.OverthrownLabel.AutoSize = true;
            this.OverthrownLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.857143F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.OverthrownLabel.Location = new System.Drawing.Point(698, 432);
            this.OverthrownLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.OverthrownLabel.Name = "OverthrownLabel";
            this.OverthrownLabel.Size = new System.Drawing.Size(296, 29);
            this.OverthrownLabel.TabIndex = 16;
            this.OverthrownLabel.Text = "Nations Overthrown: 0/195";
            this.OverthrownLabel.Visible = false;
            this.OverthrownLabel.Click += new System.EventHandler(this.OverthrownLabel_Click);
            // 
            // TakeoverButton
            // 
            this.TakeoverButton.BackColor = System.Drawing.SystemColors.Control;
            this.TakeoverButton.Enabled = false;
            this.TakeoverButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.TakeoverButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TakeoverButton.Location = new System.Drawing.Point(476, 520);
            this.TakeoverButton.Margin = new System.Windows.Forms.Padding(4);
            this.TakeoverButton.Name = "TakeoverButton";
            this.TakeoverButton.Size = new System.Drawing.Size(214, 93);
            this.TakeoverButton.TabIndex = 17;
            this.TakeoverButton.Text = "Attempt Takeover ($100000)";
            this.TakeoverButton.UseVisualStyleBackColor = false;
            this.TakeoverButton.Visible = false;
            this.TakeoverButton.Click += new System.EventHandler(this.TakeoverButton_Click);
            // 
            // BarracksLabel
            // 
            this.BarracksLabel.AutoSize = true;
            this.BarracksLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.857143F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BarracksLabel.Location = new System.Drawing.Point(699, 340);
            this.BarracksLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.BarracksLabel.Name = "BarracksLabel";
            this.BarracksLabel.Size = new System.Drawing.Size(132, 29);
            this.BarracksLabel.TabIndex = 18;
            this.BarracksLabel.Text = "Barracks: 0";
            this.BarracksLabel.Visible = false;
            this.BarracksLabel.Click += new System.EventHandler(this.BarracksLabel_Click);
            // 
            // EquipmentLabel
            // 
            this.EquipmentLabel.AutoSize = true;
            this.EquipmentLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.857143F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.EquipmentLabel.Location = new System.Drawing.Point(698, 400);
            this.EquipmentLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.EquipmentLabel.Name = "EquipmentLabel";
            this.EquipmentLabel.Size = new System.Drawing.Size(360, 29);
            this.EquipmentLabel.TabIndex = 19;
            this.EquipmentLabel.Text = "Equipment Level: Soviet Surplus";
            this.EquipmentLabel.Visible = false;
            this.EquipmentLabel.Click += new System.EventHandler(this.EquipmentLabel_Click);
            // 
            // OverthrowChanceLabel
            // 
            this.OverthrowChanceLabel.AutoSize = true;
            this.OverthrowChanceLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.857143F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.OverthrowChanceLabel.Location = new System.Drawing.Point(699, 461);
            this.OverthrowChanceLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.OverthrowChanceLabel.Name = "OverthrowChanceLabel";
            this.OverthrowChanceLabel.Size = new System.Drawing.Size(293, 29);
            this.OverthrowChanceLabel.TabIndex = 20;
            this.OverthrowChanceLabel.Text = "Successful Overthrow: 0%";
            this.OverthrowChanceLabel.Visible = false;
            this.OverthrowChanceLabel.Click += new System.EventHandler(this.OverthrowChanceLabel_Click);
            // 
            // ResearcherButton
            // 
            this.ResearcherButton.BackColor = System.Drawing.SystemColors.Control;
            this.ResearcherButton.Enabled = false;
            this.ResearcherButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ResearcherButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ResearcherButton.Location = new System.Drawing.Point(476, 419);
            this.ResearcherButton.Margin = new System.Windows.Forms.Padding(4);
            this.ResearcherButton.Name = "ResearcherButton";
            this.ResearcherButton.Size = new System.Drawing.Size(214, 93);
            this.ResearcherButton.TabIndex = 21;
            this.ResearcherButton.Text = "Hire Researcher ($25000)";
            this.ResearcherButton.UseVisualStyleBackColor = false;
            this.ResearcherButton.Visible = false;
            this.ResearcherButton.Click += new System.EventHandler(this.ResearcherButton_Click);
            // 
            // BarracksButton
            // 
            this.BarracksButton.BackColor = System.Drawing.SystemColors.Control;
            this.BarracksButton.Enabled = false;
            this.BarracksButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BarracksButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.857143F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BarracksButton.Location = new System.Drawing.Point(703, 523);
            this.BarracksButton.Margin = new System.Windows.Forms.Padding(4);
            this.BarracksButton.Name = "BarracksButton";
            this.BarracksButton.Size = new System.Drawing.Size(155, 96);
            this.BarracksButton.TabIndex = 22;
            this.BarracksButton.Text = "Buy Barracks ($50,000)";
            this.BarracksButton.UseVisualStyleBackColor = false;
            this.BarracksButton.Visible = false;
            this.BarracksButton.Click += new System.EventHandler(this.BarracksButton_Click);
            // 
            // EquipmentInfoLabel
            // 
            this.EquipmentInfoLabel.AutoSize = true;
            this.EquipmentInfoLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.142858F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.EquipmentInfoLabel.Location = new System.Drawing.Point(476, 633);
            this.EquipmentInfoLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.EquipmentInfoLabel.Name = "EquipmentInfoLabel";
            this.EquipmentInfoLabel.Size = new System.Drawing.Size(406, 25);
            this.EquipmentInfoLabel.TabIndex = 24;
            this.EquipmentInfoLabel.Text = "(Equipment Upgrades Every 25 Researchers)";
            this.EquipmentInfoLabel.Visible = false;
            this.EquipmentInfoLabel.Click += new System.EventHandler(this.EquipmentInfoLabel_Click);
            // 
            // ResearcherLabel
            // 
            this.ResearcherLabel.AutoSize = true;
            this.ResearcherLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.857143F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ResearcherLabel.Location = new System.Drawing.Point(701, 490);
            this.ResearcherLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.ResearcherLabel.Name = "ResearcherLabel";
            this.ResearcherLabel.Size = new System.Drawing.Size(175, 29);
            this.ResearcherLabel.TabIndex = 25;
            this.ResearcherLabel.Text = "Researchers: 0";
            this.ResearcherLabel.Visible = false;
            // 
            // Main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(11F, 24F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlDark;
            this.ClientSize = new System.Drawing.Size(1161, 891);
            this.Controls.Add(this.ResearcherLabel);
            this.Controls.Add(this.EquipmentInfoLabel);
            this.Controls.Add(this.BarracksButton);
            this.Controls.Add(this.ResearcherButton);
            this.Controls.Add(this.OverthrowChanceLabel);
            this.Controls.Add(this.EquipmentLabel);
            this.Controls.Add(this.BarracksLabel);
            this.Controls.Add(this.TakeoverButton);
            this.Controls.Add(this.OverthrownLabel);
            this.Controls.Add(this.OpsCenterLabel);
            this.Controls.Add(this.SoilderLabel);
            this.Controls.Add(this.MilitiaButton);
            this.Controls.Add(this.EmployeeIncomeLabel);
            this.Controls.Add(this.EmployeesLabel);
            this.Controls.Add(this.HireButton);
            this.Controls.Add(this.InstructionButton);
            this.Controls.Add(this.UpgradeLabel);
            this.Controls.Add(this.UpgradePanel);
            this.Controls.Add(this.CALabel);
            this.Controls.Add(this.Mpplabel);
            this.Controls.Add(this.Mplabel);
            this.Controls.Add(this.mpcButton);
            this.Controls.Add(this.IncrementLabel);
            this.Controls.Add(this.Moneybutton);
            this.Controls.Add(this.Moneylabel);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Main";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label Moneylabel;
        private System.Windows.Forms.Button Moneybutton;
        private System.Windows.Forms.Label IncrementLabel;
        private System.Windows.Forms.Button mpcButton;
        private System.Windows.Forms.Label Mplabel;
        private System.Windows.Forms.Label Mpplabel;
        private System.Windows.Forms.Label CALabel;
        private System.Windows.Forms.Timer UpdateLabels;
        private System.Windows.Forms.Timer PrinterUpdate;
        private System.Windows.Forms.Timer AutoSave;
        private System.Windows.Forms.Panel UpgradePanel;
        private System.Windows.Forms.Label UpgradeLabel;
        private System.Windows.Forms.Timer MoneyRain;
        private System.Windows.Forms.Button InstructionButton;
        private System.Windows.Forms.Button HireButton;
        private System.Windows.Forms.Label EmployeesLabel;
        private System.Windows.Forms.Label EmployeeIncomeLabel;
        private System.Windows.Forms.Timer EmployeeIncomeTimer;
        private System.Windows.Forms.Button MilitiaButton;
        private System.Windows.Forms.Label SoilderLabel;
        private System.Windows.Forms.Label OpsCenterLabel;
        private System.Windows.Forms.Label OverthrownLabel;
        private System.Windows.Forms.Button TakeoverButton;
        private System.Windows.Forms.Label BarracksLabel;
        private System.Windows.Forms.Label EquipmentLabel;
        private System.Windows.Forms.Label OverthrowChanceLabel;
        private System.Windows.Forms.Button ResearcherButton;
        private System.Windows.Forms.Button BarracksButton;
        private System.Windows.Forms.Label EquipmentInfoLabel;
        private System.Windows.Forms.Label ResearcherLabel;
    }
} 