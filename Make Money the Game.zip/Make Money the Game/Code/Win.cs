﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ManageGame
{
    public partial class Win : Form
    {
        Random rng = new Random();
        public Win()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            this.BackColor = GetColor();
        }
        private Color GetColor()
        {
            int r = rng.Next(256);
            int g = rng.Next(256);
            int b = rng.Next(256);
            return Color.FromArgb(r, g, b);
        }
    }
}
